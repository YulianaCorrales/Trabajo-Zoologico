
package com.mycompany.zoologicoay2;


public class Clientes 
{
    private String cedula;
    private String nombre;
    private float valorPagado;
    private int numeroVisitas;
    private char planElegido;
    
    public Clientes()
    {
        
    }
    
    public Clientes(String pCedula, String pNombre, float pValorPagado, char pPlanElegido)
    {
        this.cedula=pCedula;
        this.nombre=pNombre;
        this.valorPagado=pValorPagado;
        this.planElegido=pPlanElegido;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public char getPlanElegido() {
        return planElegido;
    }

    public void setPlanElegido(char planElegido) {
        this.planElegido = planElegido;
    }

    public float getValorPagado() {
        return valorPagado;
    }

    public void setValorPagado(float valorPagado) {
        this.valorPagado = valorPagado;
    }
    
    
    
}
    
   