
package com.mycompany.zoologicoay2;


public class AnimalesSalvajes extends Animal
{
    private String nivelPeligrosidad;
    private String habitatNatural;
    private String dieta;
    
    public AnimalesSalvajes()
    {
        
    }

    public AnimalesSalvajes(String nivelPeligrosidad, String habitatNatural, String dieta,  String pEspecie, int pEdad, String pGenero) 
    {
        super(pEspecie, pEdad, pGenero);
        this.nivelPeligrosidad = nivelPeligrosidad;
        this.habitatNatural = habitatNatural;
        this.dieta = dieta;
    }

    public String getDieta() {
        return dieta;
    }

    public void setDieta(String dieta) {
        this.dieta = dieta;
    }

    public String getHabitatNatural() {
        return habitatNatural;
    }

    public void setHabitatNatural(String habitatNatural) {
        this.habitatNatural = habitatNatural;
    }

    public String getNivelPeligrosidad() {
        return nivelPeligrosidad;
    }

    public void setNivelPeligrosidad(String nivelPeligrosidad) {
        this.nivelPeligrosidad = nivelPeligrosidad;
    }
    
    
    
    
}
