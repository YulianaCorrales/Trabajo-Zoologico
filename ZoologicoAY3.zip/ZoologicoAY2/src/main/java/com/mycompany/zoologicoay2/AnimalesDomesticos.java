
package com.mycompany.zoologicoay2;


public class AnimalesDomesticos extends Animal
{
    private float precio;
    private String uso;
    private String raza;
    
    public AnimalesDomesticos()
    {
        
    }

    public AnimalesDomesticos(float pPrecio, String pUso, String pRaza, String pEspecie, int pEdad, String pGenero) {
        super(pEspecie, pEdad, pGenero);
        this.precio = pPrecio;
        this.uso = pUso;
        this.raza = pRaza;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getUso() {
        return uso;
    }

    public void setUso(String uso) {
        this.uso = uso;
    }

    
       
}
