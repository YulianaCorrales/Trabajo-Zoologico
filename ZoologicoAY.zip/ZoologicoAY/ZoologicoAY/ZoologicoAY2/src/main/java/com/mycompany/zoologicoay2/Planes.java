
package com.mycompany.zoologicoay2;


public class Planes 
{
    private String nombrePlan;
    private String atraccionIncluida;
    private float precioPlan;
    
    public Planes()
    {
        
    }

    public Planes(String pNombrePlan, String pAtraccionIncluida, float pPrecioPlan) {
        this.nombrePlan = pNombrePlan;
        this.atraccionIncluida = pAtraccionIncluida;
        this.precioPlan = pPrecioPlan;
    }

    public String getAtraccionIncluida() {
        return atraccionIncluida;
    }

    public void setAtraccionIncluida(String atraccionIncluida) {
        this.atraccionIncluida = atraccionIncluida;
    }

    public String getNombrePlan() {
        return nombrePlan;
    }

    public void setNombrePlan(String nombrePlan) {
        this.nombrePlan = nombrePlan;
    }

    public float getPrecioPlan() {
        return precioPlan;
    }

    public void setPrecioPlan(float precioPlan) {
        this.precioPlan = precioPlan;
    }
    
    
}
