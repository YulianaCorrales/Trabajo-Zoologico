/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.zoologicoay2;

/**
 *
 * @author Yuliana Corrales & Alejandro Vargas
 */
public class ZoologicoAY2 {
    public static void  main(String[] args)
    {
        Inicio inicio = new Inicio();
        inicio.setVisible(true);
    }
    
}
