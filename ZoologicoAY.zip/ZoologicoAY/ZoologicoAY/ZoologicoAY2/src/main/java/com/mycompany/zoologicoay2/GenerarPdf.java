/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.zoologicoay2;

import javax.swing.JFrame;
import com.mycompany.zoologicoay2.VentasAnimales;
import com.itextpdf.text.*;
import java.io.FileOutputStream;
import java.util.ArrayList;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import static com.mycompany.zoologicoay2.VentasAnimales.datosClientes;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author Yuliana Corrales, Alejandro Vargas
 */
public class GenerarPdf 
{

    
   public static void  main(String[] args) throws FileNotFoundException, DocumentException, BadElementException, IOException{
//       VentasAnimales listaClientes = new VentasAnimales();
//       ArrayList<Clientes> lista = listaClientes.getDatosClientes();

        
        
        
        Document documento = new Document( PageSize.A4,50,50,50,50);
        
        try {
           PdfWriter.getInstance(documento, new FileOutputStream ("C:/Users/Wings and Beer/Documents/NetBeansProjects/pdf.pdf"));
             
            documento.open();
            Image imagen = Image.getInstance("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSaWkV1k6f3e1JXH5-64XW0FzcyZEBlvvvJpg&usqp=CAU");
            imagen.scaleToFit(120, 120);
            imagen.setAlignment(Chunk.ALIGN_CENTER);
            documento.add(imagen);
            
            documento.add(new Paragraph ("ZOOLÓGICO AY"));
            documento.add(new Paragraph ("TELÉFONO: 604 773 23 98"));
            documento.add(new Paragraph ("CLL 23 A # 40-15 MEDELLÍN, ANTIOQUIA"));
            documento.add(new Paragraph ("CORREO: ZOOLOGICO@AY.COM"));
            
       
          PdfPTable table= new  PdfPTable ( 4 ); 
          
                table.addCell("Cédula");
                table.addCell("Nombre");
                table.addCell("Plan elegido");
                table.addCell("Valor a pagar");
                
                  
                     for (String cell : datosClientes) {
                PdfPCell pdfCell = new PdfPCell(new Paragraph(cell));
                table.addCell(pdfCell);
            
}
               documento.add(new Paragraph ());
                documento.add(table);
            }

            // Cerrar el documento
           

           // System.out.println("Archivo PDF creado correctamente.");
         catch (Exception e) {
            System.err.println("Error al crear archivo PDF: " + e.getMessage());
        }
        finally{
         documento.close();
       }
   } 

    void imprimir() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void generarPdf() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

    
    
  

        
 


