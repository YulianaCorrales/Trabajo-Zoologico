
package com.mycompany.zoologicoay2;


public class Animal 
{
    
    private String especie;
    private int edadAnimal;
    private String genero;
    
    public Animal()
    {
        
    }
    
    public Animal(String pEspecie, int pEdadAnimal, String pGenero)
    {
        this.edadAnimal=pEdadAnimal;
        this.especie=pEspecie;
        this.edadAnimal=pEdadAnimal;
        this.genero=pGenero;
    }

    public int getEdad() {
        return edadAnimal;
    }

    public void setEdad(int pEdadAnimal) {
        this.edadAnimal = pEdadAnimal;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String pEspecie) {
        this.especie = pEspecie;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String pGenero) {
        this.genero = pGenero;
    }

    
    
    
}
